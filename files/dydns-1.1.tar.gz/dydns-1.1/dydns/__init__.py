#!/usr/bin/env python
"""This module updates DNS records"""

import socket
import dns.query
import dns.tsigkeyring
import dns.update

def dydns(hostname, ipaddress):
    "This function updates DNS when ran."
    keyring = dns.tsigkeyring.from_text({
        'dhcpupdate.' : 'n5yNWWlh6yhWt2KoYA0Wtg=='
    })
    update = dns.update.Update('novalocal.', keyring=keyring)
    update.replace(hostname, 300, 'A', ipaddress)
    response = dns.query.tcp(update, '10.1.0.167')
    return response

HOSTNAME = socket.gethostname()
IPADDRESS = socket.gethostbyname(HOSTNAME)

HOSTNAME = HOSTNAME.split('.')[0]

print HOSTNAME + " " + IPADDRESS

def dnsupdate():
    "This executes the dydns update when ran."
    response = dydns(HOSTNAME, IPADDRESS)
    return response
