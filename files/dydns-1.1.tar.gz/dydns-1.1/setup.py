from setuptools import setup
setup(name='dydns',
      version='1.1',
      description='Updates DNS with Host A records',
      url='http://github.cerner.com/ct046686/DyDNS',
      author='Cory Twitty',
      author_email='cory.twity@cerner.com',
      license='MIT',
      packages=['dydns'],
      zip_safe=False,
      scripts=['bin/pynsupdate'],
      install_requires=[
          'dnspython',
      ])
